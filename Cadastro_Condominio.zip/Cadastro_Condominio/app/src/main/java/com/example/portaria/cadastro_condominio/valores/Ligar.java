package com.example.portaria.cadastro_condominio.valores;

import android.support.v7.app.AppCompatActivity;



public class Ligar extends AppCompatActivity {
    public static String condominio;
    public static String casa;
    public static boolean ok;
    public static String pesquisar;






}
